GlitchVerse 3D

How to run
1. Extract the ZIP into a folder, or open index.html from the ZIP.
2. Open index.html in a modern browser (Chrome, Edge, or Firefox).
3. Click or tap once if the browser has not started audio yet. Browsers require a user gesture before playing sound.

Character powers
Choose Rin or Vex before starting a level. Both powers use Q and recharge in 9.5 seconds.
- Vex — Shadow Step: phase through spikes, saws, and the Root Guardian for 0.72 seconds. Solid walls still block movement.
- Rin — Ronin Guard: for 1.35 seconds, block the next hit from a spike, saw, or the Root Guardian. The block also grants a brief 0.65-second grace period against another hit.

Controls
- Move: A/D or Left/Right arrows
- Jump: Space, W, or Up arrow
- Flip gravity: G or X (where enabled)
- Freeze hazards: hold F or Z (where enabled)
- Dash: C or K (where enabled)
- Switch dimension: E or either Shift key (where enabled)
- Character power: Q
- Pause: P or Escape; restart: R; mute: M

The game music and sound effects are synthesized with Web Audio; no separate audio files are needed. Google Fonts may load online; system fonts are used when offline.
