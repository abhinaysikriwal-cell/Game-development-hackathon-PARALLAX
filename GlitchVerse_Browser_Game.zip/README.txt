GLITCHVERSE: Protocol Axiom-0 — Browser Edition

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in a modern browser (Chrome or Edge recommended).
3. Click “INITIALIZE SIMULATION (PLAY 3D)”.

CONTROLS (as defined by the source)
W/A/S/D: Move
Space: Jump / cutscene skip
Q or 1: Gravity inversion
E or 2: Chrono stasis
F or 3: Dimension phase shift
C or 4: Quantum mass
G: Grab/drop cube
R: Restart sector
B: Cycle cosmos vista
M: Toggle audio
J/L: Rotate camera

NOTES
- The source loads Three.js, Tailwind CSS, and fonts from external CDNs, so those resources require an internet connection when running this build as-is.
- This is the provided HTML/JavaScript browser game packaged for direct use and GitHub Pages. It is not a compiled Unity project.
- Browser smoke tests can confirm page load and JavaScript syntax, but do not prove every gameplay path is bug-free.
