@echo off
setlocal
set "GAME_DIR=%~dp0"
cd /d "%GAME_DIR%"
set "PORT=8766"
set "PYTHON_EXE="

if not exist "%GAME_DIR%index.html" (
  echo Could not find index.html next to Start Game.cmd.
  echo Extract the complete ZIP into a regular folder, then run this launcher there.
  pause
  exit /b 1
)

if defined USERPROFILE if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" set "PYTHON_EXE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not defined PYTHON_EXE for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
if not defined PYTHON_EXE for /f "delims=" %%P in ('where py 2^>nul') do if not defined PYTHON_EXE set "PYTHON_EXE=%%P"

if not defined PYTHON_EXE (
  echo Python was not found. Install Python, or publish this folder with GitHub Pages.
  pause
  exit /b 1
)

:find_port
powershell -NoProfile -Command "$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, %PORT%); try { $listener.Start(); $listener.Stop(); exit 0 } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
  set /a PORT+=1
  goto find_port
)

start "Mumbai Null Signal server %PORT%" /min /D "%GAME_DIR%" "%PYTHON_EXE%" -m http.server %PORT% --bind 127.0.0.1
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:%PORT%/index.html"
echo Mumbai Null Signal is running at http://127.0.0.1:%PORT%/index.html
echo Keep the minimized server window open while you play.
echo Close the server window when you are finished.
pause